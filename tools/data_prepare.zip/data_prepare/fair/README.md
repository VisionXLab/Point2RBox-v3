# Preparing FAIR Dataset

```
@article{sun2022fair1m,
title = {FAIR1M: A benchmark dataset for fine-grained object recognition in high-resolution remote sensing imagery},
journal = {ISPRS Journal of Photogrammetry and Remote Sensing},
volume = {184},
pages = {116-130},
year = {2022},
issn = {0924-2716},
author = {Xian Sun and Peijin Wang and Zhiyuan Yan and Feng Xu and Ruiping Wang and Wenhui Diao and Jin Chen and Jihao Li and Yingchao Feng and Tao Xu and Martin Weinmann and Stefan Hinz and Cheng Wang and Kun Fu},
}
```
